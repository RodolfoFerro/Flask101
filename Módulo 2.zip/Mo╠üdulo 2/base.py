def saludo():
    name = input("Introduce tu nombre: ")
    print(f"Mucho gusto, {name}")


if __name__ == '__main__':
    saludo()
