dieta = {
    "lunes": "Mole con pollo.",
    "martes": "Ensalada de atún.",
    "viernes": "Pizza de carne con queso, con piña, con más carne."
}

estudiante = {
    "edad": 26,
    "nombre": "Rodolfo",
    "temas": [
        "Inteligencia Artificial",
        "Desarrollo web",
        "Python"
    ]
}

print("Mi dieta del viernes es:")
print(dieta['viernes'])
print()

print(estudiante['nombre'])
print(estudiante['edad'])
print(estudiante['temas'])
