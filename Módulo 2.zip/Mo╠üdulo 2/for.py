materias = [
    "Ecuaciones Diferenciales",
    "Dinámica de Sistemas",
    "Anatomía y Fisiología II",
    "Diseño Mecánico"
]

for materia in materias:
    print(f"- {materia}")
