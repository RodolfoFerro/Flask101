nombre = input("¿Cómo te llamas? ")
print("Mucho gusto,", nombre, ".")
print("Mucho gusto, {}.".format(nombre))
print(f"Mucho gusto, {nombre}.")
