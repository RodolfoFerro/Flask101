from funciones import pide_edad
from funciones import legal_o_no

edad = pide_edad()
print(legal_o_no(edad))
