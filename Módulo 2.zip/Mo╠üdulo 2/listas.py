compras = [
    "Sillón",
    "Agua",
    "Cloro",
    "Brócoli"
]

print(f"Total de cosas por comprar: {len(compras)}")
print(f"El tercer elemento de la lista es: {compras[2]}")

compras[2] = "Manzana"
print(compras)
