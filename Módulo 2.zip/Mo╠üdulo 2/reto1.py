# Entrada de datos:
name = input("Introduce tu nombre: ")
age = input("Introduce tu edad: ")
age = int(age)

# Imprimo información del nombre:
print(f"Mucho gusto, {name}.")
print(f"Tu nombre es una variable de tipo {type(name)}.")

# Imprimo información de la edad:
print(f"Tienes {age} años.")
print(f"Tu edad es una variable de tipo {type(age)}.")
