name = "Rodolfo"
age = 26
pi = 3.14159265358979

print(name, type(name))
print(age, type(age))
print(pi, type(pi))
