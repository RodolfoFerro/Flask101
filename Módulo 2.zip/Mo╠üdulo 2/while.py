age = int(input("Introduce tu edad: "))

while age <= 100:
    # print(f"Tienes menos de 100 años, de hecho, tienes {age}.")
    age = age + 1
    # print("Feliz cumpleaños.")
    if age == 100:
        print("Ya estás viejit@.")
