from pymongo import MongoClient


if __name__ == '__main__':
    print("MongoClient imported successfully!")
